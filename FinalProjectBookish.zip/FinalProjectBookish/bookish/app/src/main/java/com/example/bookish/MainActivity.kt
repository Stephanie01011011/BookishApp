package com.example.bookish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var goal = intent.getStringExtra("goal")
        goaltext.text= goal

        reviewbutton.setOnClickListener {
            val intent = Intent(this, SecondaryActivity::class.java)
            startActivity(intent)
        }
        settings.setOnClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }


    }
    fun display(view: View){
        helpInfo.text="The purpose of this app is to have a space to record any books you have read " +
                "and give a more detailed but simple rating and description of each book." +
                "The Settings section will allow you to set a reading goal for the year, as well as set your username while" +
                "using the bookish app."
    }

}
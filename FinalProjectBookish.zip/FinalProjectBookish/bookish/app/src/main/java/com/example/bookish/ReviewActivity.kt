package com.example.bookish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_review.*
import kotlinx.android.synthetic.main.activity_setting.*


class ReviewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        var title = intent.getStringExtra("title")
        var author = intent.getStringExtra("author")
        var genre = intent.getStringExtra("genre")
        var rating = intent.getStringExtra("rating")
        var review = intent.getStringExtra("review")
        titletext.text= title
        authortext.text= author
        genretext.text = genre
        ratingtext.text= rating
        reviewtext.text = review



    }
    fun goHome(view: View){
        val home = Intent(this, MainActivity::class.java)

        startActivity(home)
    }


}
package com.example.bookish

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_review.*
import kotlinx.android.synthetic.main.activity_secondary.*


class SecondaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)


        submitbutton.setOnClickListener {
            val intent = Intent(this, ReviewActivity::class.java)
            intent.putExtra("title", booktitle.text.toString())
            intent.putExtra("author", bookauthor.text.toString())
            intent.putExtra("genre", bookgenre.text.toString())
            intent.putExtra("rating", bookrating.text.toString())
            intent.putExtra("review", bookreviewtext.text.toString())
            startActivity(intent)

        }
    }
}